// --------------------------------------------------
// Dependencias
// --------------------------------------------------

var gulp = require('gulp'),

	// Watch new files
	watch = require('gulp-watch'), // Verifica novos arquivos

	// Helpers
	gutil = require('gulp-util'), // Utilidades, log etc.
	plumber = require('gulp-plumber'), // Para não quebrar os "pipes" caso aconteça algum erro e pare de rodar o watch por exemplo.

	// CSS
	sass = require('gulp-sass'), // SASS ᕙ(⌐■_■)ᕗ
	autoprefixer = require('gulp-autoprefixer'), // Adiciona os vendor prefixes automaticamente
	cleanCSS = require('gulp-clean-css'), // Comprime e otimiza o css

	// JS
	jshint = require('gulp-jshint'), // "dicas" sobre o js
	stripDebug = require('gulp-strip-debug'), // Remove os debugs como: console.log, alert etc.
	uglify = require('gulp-uglify'), // Comprime o js

	// IMG
	imagemin = require('gulp-imagemin'), // Otimiza as imagens
	pngquant = require('imagemin-pngquant'), // Otimiza png
	newer = require('gulp-newer'), // Compara o destino com a origem
	babel = require('gulp-babel'),

	// LIVE RELOAD
	browserSync = require('browser-sync').create(); // Atualiza o browser a cada modificação. Funciona melhor junto a extenção Livereload instalada no browser


// --------------------------------------------------
// Varáveis principais
// --------------------------------------------------

// Origens
var paths = {
	style: ['./assets/style/**/*.scss'],
	script: ['./assets/script/**/*.js'],
	images: ['./assets/images/**/*'],
	deploy: ['./*.*', './dist/**', '!./assets/**', '!./node_modules/**', '!./gulpfile.js', '!./.sublime-gulp.cache', '!./npm-debug.log', '!./package.json', '!.*.cache', '!./dist/images/uploads/**', './functions/**']
};

// Destino dos arquivos compilados
var dest = './dist/';


// --------------------------------------------------
//  Tasks
// --------------------------------------------------

// Compila o SASS e otimiza o CSS
gulp.task('sass', function () {
	gulp.src(paths.style)
		.pipe(sass({
			includePaths: ['./assets/style/main', './assets/style/inc', './assets/style']
		}).on('error', sass.logError))
		// .pipe(sass().on('error', sass.logError))
		// .pipe(cleanCSS())
		.pipe(autoprefixer("last 40 version", "> 1%", "ie 8"))
		.pipe(gulp.dest(dest + 'style/'));
});


// Otimiza JS
gulp.task('script', ['jshint'], function () {
	gulp.src(paths.script)
		.pipe(babel())
		.pipe(plumber())
		.pipe(newer(dest + 'script/'))
		//.pipe(stripDebug())
		//.pipe(uglify())
		.pipe(gulp.dest(dest + 'script/'));
});

// __JS hint
gulp.task('jshint', function () {
	gulp.src(['assets/script/**/*', '!./assets/script/vendor/**/*'])
		.pipe(jshint())
		.pipe(jshint.reporter('default'))
});


// Otimiza imagens
gulp.task('images', function () {
	return gulp.src(paths.images)
		.pipe(plumber())
		.pipe(newer(dest + 'images/'))
		.pipe(imagemin({
			progressive: true,
			optimizationLevel: 7,
			use: [pngquant({
				quality: '50-60',
				speed: 10
			})]
		}))
		.pipe(gulp.dest(dest + 'images/'));
});

// Cria o servidor para sincronizar o browser
gulp.task('browser-sync-setup', function () {
	browserSync.init({
		proxy: "localhost/andia"
	});
});

// Atualiza o browser após o Sass - USADO OFFLINE
gulp.task('browser-sync-refresh', function () {
	browserSync.reload();
});


// Verifica alterações  - METODO NOVO
gulp.task('watch', function () {
	watch(paths.images, function () {
		gulp.start('images');
	});
	watch(paths.style, function () {
		gulp.start('sass');
	});
	watch(paths.script, function () {
		gulp.start('script');
	});
	watch(paths.deploy, function () {
		gulp.start('browser-sync-refresh');
	});
});

// Task padrão
gulp.task('default', ['watch', 'browser-sync-setup']);