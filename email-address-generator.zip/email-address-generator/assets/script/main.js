document.addEventListener("DOMContentLoaded", function () {

  let xmpGoes = document.querySelector('[data-inputXmp]');
  xmpGoes == null ? console.log('Please insert the "data-inputXmp" in a <div> tag.') :
    xmpGoes.insertAdjacentHTML('afterbegin', '<xmp id="addressCode" data-xmp></xmp>');

  let funfa = new CardEmailAddress();
  funfa.bindInputs();

  let clipboardButton = document.querySelector('.clipboardButton');
  clipboardButton.addEventListener('click', () => {
    let addressTable = document.querySelector('[data-addressTable]');
    let newAddressTable = addressTable.cloneNode(true);
    let xmp = document.querySelector('[data-xmp]');

    xmp.innerHTML = newAddressTable.innerHTML;

    let clipboard = new ClipboardJS('.clipboardButton', {
      text: function (trigger) {
        return xmp.innerHTML;
      }
    });

    clipboard.on('success', (e) => {
      let clipboardCopied = document.querySelector('.clipboard__copied');
      clipboardCopied.classList.add('active');
      setTimeout(function () {
        clipboardCopied.classList.remove('active');
      }, 5000);
    });
  });

});


// CardEmailAddress Object
function CardEmailAddress() {
  this.inputs = document.querySelectorAll('[data-bind]');
  this.bindInputs = () => {
    if (this.inputs.length > 0) {
      for (let i = 0; i < this.inputs.length; i++) {
        this.inputs[i].addEventListener('input', () => {
          let inputType = document.getElementById(this.inputs[i].dataset.bind);
          if (inputType.id == 'addressName') {
            inputType.innerHTML = this.inputs[i].value;
          } else {
            inputType.innerHTML = this.inputs[i].value.italics();
          }
        });
      }
    } else {
      console.log('No data-bind finded ;-;\'');
    }
  }
}